# Handoff: TLC Front Desk — Call Center #2 (vertical slice)

## Overview

A mobile game prototype set in **The Realm**. The player is a first-day support agent at
**Call Center #2** of the **Translocation & Logistics Cooperative (TLC)** in the Village of Import.
They answer one inbound ley-line call, discover who is calling, classify the ticket, investigate
with a limited time budget, diagnose the problem, and dispose of the ticket. The shift is bounded
by a candle that burns down as the player spends time.

The slice is a complete loop: **Clock-in → The Line → The Call (4 phases) → Diagnosis → Disposition → End of Day**,
with two side screens (**Account Record**, **Break Room**) and one interstitial (**Figurehead Notice**).

Core design intent, in one line: *you pick up blind, and everything you know you had to ask for.*

## About the Design Files

The files in this bundle are **design references created in HTML** — a running prototype that
demonstrates intended look, copy, and behavior. They are **not production code to copy directly**.

The task is to **recreate this design in the target codebase's existing environment** (SwiftUI,
React Native, Unity, Godot, web — whatever the team is building the game in), using that
environment's established patterns, asset pipeline, and state management. If no environment
exists yet, choose the framework appropriate for a portrait-orientation mobile narrative game
and implement there.

One notable exception to "don't copy the code": the character/scene art is **generated
procedurally in JavaScript** inside the prototype (see *Assets* below). That generator is a
placeholder standing in for real pixel art. Ship real sprites; do not port the generator.

## Fidelity

**High-fidelity (hifi).** Colors, typography, spacing, copy, and interaction states are final-intent.
Every value in this document is the actual value used in the prototype. Recreate the UI closely.

Two caveats:
- **Art is placeholder.** The busts, scene, candle, and sigil are procedurally drawn stand-ins at
  the correct dimensions and in the correct palette. Commission real 32-bit pixel art to the
  same sizes and silhouettes.
- **Content is one authored call.** All dialogue, findings, and outcomes are a single hand-written
  case. Production needs a content pipeline (data-driven cases), not hardcoded arrays.

## Device & Canvas

- Portrait phone frame: **393 × 852** (iPhone 14/15 logical size). The prototype draws a
  decorative bezel around it and a debug "Screen Index" rail beside it — **both are prototype
  chrome, not part of the app.**
- Layout is a vertical flex column: fixed **status bar** (top), scrolling/filling **screen body**,
  and on some screens a fixed **action tray** (bottom).
- The app itself is fluid within the safe area; nothing depends on the exact 393 × 852.

---

## Screens / Views

Screen state is a single enum: `clockin | line | call | record | breakroom | policy | summary`.

### 0. Status bar (persistent, all screens)

- Height: content-driven, padding `9px 12px`. Background `linear-gradient(180deg, #1d2b3c, #111a25)`,
  inset top highlight `rgba(255,255,255,.09)`, 1px bottom rule `#3a536e`.
- **Left:** 20×20 TLC sigil sprite + label `TLC · Support Center` — Jersey 15, 15px, `#a9c2d8`,
  letter-spacing 1.2px.
- **Right:** candle status text (Jersey 15, 13px, `#8098af`, letter-spacing 1.5px) + the
  **candle sprite** 22×42, `object-fit: contain`, `object-position: bottom center`.
- Candle status text is derived from remaining fraction `left / max`:

  | Fraction | Text |
  | --- | --- |
  | `= 1` | `newly lit` |
  | `0.7 ≤ f < 1` | `burning steady` |
  | `0.4 < f ≤ 0.7` | `burning down` |
  | `0.2 < f ≤ 0.4` | `burning low` |
  | `0 < f ≤ 0.2` | `guttering` |
  | `= 0` | `the wick is out` |

  **There is no numeric timer anywhere in the UI.** The candle is the clock.

### 1. Clock-in

**Purpose:** establish date, place, tone; start the shift.

- Background `linear-gradient(180deg, #14202d, #0c1219)`.
- **Scene sprite:** full width 393 × 246, 1px bottom rule `#3a536e`.
- Body: `padding: 20px 18px 22px`, `gap: 18px`, vertically centered.
  - Kicker: `MONDAY · 14 HARVEST 1147` — Jersey 15, 15px, `#8fa8bf`, letter-spacing 3px.
  - Title: `Call Center #2` — Jersey 15, **52px**, line-height .92, `#f2f6fa`,
    text-shadow `0 2px 0 #0a0f16, 0 3px 0 rgba(110,143,176,.35)`.
  - Body copy: 16px/1.5, `#a9c2d8`, `max-width: 320px`:
    > Translocation & Logistics Cooperative. Village of Import. The candle is whole, the line is not empty, and nobody on it has told you their name yet.
  - **Notice panel** (bevel panel, see *Panels*): kicker `POSTED THIS MORNING`; body 15px/1.45 `#d5e2ee`:
    > Reminder: the Loading Dock remains a Ballroom. Do not route returned packages to the Loading Dock Ballroom until further notice.
  - **Primary button:** `LIGHT THE CANDLE` → screen `line`.

### 2. The Line

**Purpose:** choose to pick up. The player is given *no* caller identity up front.

- Padding `16px 14px 18px`, gap 13px.
- Heading `THE LINE` — Jersey 15, 34px, `#f2f6fa`. Subhead 15px/1.45 `#8fa8bf`:
  > Three interactions waiting.
  >
  > Discovering who is requesting help, why they do, and what you are capable of doing, before providing support is your goal.
- **Active call card** — bevel panel with **gold** rule (`#e0b45c`), padding 13px:
  - Row: `◆ LINE ONE · RINGING` (Jersey 15, 14px, `#e0b45c`, `animation: ring 1.6s steps(2,end) infinite`
    — opacity 1 → .35 → 1) and `HELD 00:04` (14px, `#8fa8bf`).
  - Portrait 128 × 168, border `0 0 0 1px #0a1017, 0 0 0 2px #4a6c8f`. Alt text
    "Unidentified caller"; art is the **hooded/unknown** bust, not the real caller.
  - Name `Unidentified caller` — Jersey 15, 26px, `#8fa8bf` (dimmed, *not* white — the player
    does not know this person). Sub: `Ward signature present but unmatched.` 14px `#8fa8bf`.
  - **Gold button:** `PICK UP` → screen `call`.
- **Two waiting rows** (non-interactive, `opacity: .6`), each: 32×42 thumbnail, channel line
  (Jersey 15, 18px, `#b6cadd`), note (13px, `#8098af`), hold time right-aligned:
  1. `Line two · End User channel` / `No ward signature. Nothing else offered.` / `HELD 02:11`
  2. `Line three · Business channel` / `Signature matches a high-volume account. Caller unknown.` / `HELD 05:40`
- Footer flavor, pinned bottom (`margin-top: auto`), 14px, sage:
  > On the desk you see scratched: *History doesn't repeat itself, but it does rhyme.*

### 3. The Call (the core screen)

Three regions: **caller header** (fixed), **transcript feed** (scrolls, `flex: 1`), **ask menu** (fixed bottom).

#### 3a. Caller header
- Padding `11px 12px`, background `linear-gradient(180deg, #1a2836, #121b25)`, 1px bottom rule `#3a536e`.
- Portrait 128 × 168 with double frame: `0 0 0 1px #0a1017, 0 0 0 2px #6e8fb0, 0 0 0 4px #0a1017, 0 0 0 5px #33526f`.
- **Header contents change on identification** (`identified` = the player has asked her name OR matched the ward signature):

  | | Not identified | Identified |
  | --- | --- | --- |
  | Portrait | hooded/unknown bust | Maren bust |
  | Name (Jersey 15, 28px) | `Unidentified caller`, `#8fa8bf` | `Maren Thackery`, `#f2f6fa` |
  | Sub (14px `#8fa8bf`) | `Ward signature unmatched` | `The Gilded Hound, Import · acct 0-4471` |
  | Tag 1 | `CHANNEL: UNKNOWN` (outline) | `PARTNER · NODE` (light fill `linear-gradient(180deg,#a8c4dc,#7fa2c2)`, ink `#0b1119`) |
  | Tag 2 | `UNCLASSIFIED` (outline) | current classification, uppercased, or `UNCLASSIFIED` |
  | Record link | hidden | `▸ OPEN ACCOUNT RECORD`, gold `#e0b45c`, hover `#f6d38a` |

  Tags: Jersey 15, 13px, padding `3px 7px`, `inset 0 0 0 1px` edge, letter-spacing 1.5px.

#### 3b. Transcript feed
Append-only list of bevel panels, gap 9px, padding `12px 14px`. Each entry:
- **Speaker line** — Jersey 15, 13px, letter-spacing 2px, per-entry tint.
- Optional **finding tag** on the right — Jersey 15, 11px, padding `2px 5px`, 1px inset edge.
  Two values only:
  - `AS EXPECTED` — color `#8098af`, edge `#2b3f56`, panel rule `#3f556b`
  - `DIVERGES` — color `#e0b45c`, edge `#8f6522`, panel rule `#c9963f`
- **Body** — 16px/1.5, `#eaf2f9`, `text-wrap: pretty`.

The first entry (before any player action) is the system framing:
> LINE ONE · CONNECTED — Someone is on the line. The registry offers a channel and a ward signature it cannot match. Everything else, you get by asking.

#### 3c. Ask menu (bottom tray)
- Background `linear-gradient(180deg, #16222f, #0f1720)`, top rule `#3a536e`, padding `10px 12px 12px`, gap 6px.
- Header row: menu label (Jersey 15, 14px, `#8fa8bf`, ls 2px) + candle status text (13px, `#8098af`).
- Each option is a button row: `padding: 8px 10px`, gap 9px, background
  `linear-gradient(180deg,#22344a,#16222f)`, `inset 0 0 0 1px #0a1017, inset 0 0 0 2px <edge>`;
  hover background `linear-gradient(180deg,#2b4560,#1a2937)`.
  - **Cursor glyph** (11px column, Jersey 15 16px): `▸` available (gold `#e0b45c`),
    `✓` already used (sage `#9db07c`), `·` unaffordable (`#3f556b`).
  - **Label** 15px/1.35; `#eaf2f9` available, `#8098af` used, `#3f556b` unaffordable.
  - Optional **note** 13px `#8098af` (used in classify / diagnose / disposition phases).
  - **Cost pips** right side: one 6 × 12 block per candle notch the option costs,
    fill `#e0b45c` if affordable else `#3f556b`.
  - Used options: background `linear-gradient(180deg,#182530,#111a23)`. Unaffordable: `opacity: .5`.
- Optional **gold advance button** at the bottom of the tray when the phase can be left.

#### 3d. The four call phases

State: `phase = identify → classify → ask → diagnose → status`.

**Phase 1 — `identify`** · label `OPEN THE CALL`. Options (cost in candle notches):

| Option | Cost | Response speaker | Identifies? |
| --- | --- | --- | --- |
| `"TLC Support. How may I help you?"` | 0 | CALLER · PARTNER CHANNEL | no |
| `Ask who you are speaking with` | 0 | CALLER · PARTNER CHANNEL | **yes** |
| `Match the ward signature against the registry` | 1 | LEY REGISTRY · MATCH | **yes** |
| `The name is Keyth.   How you doin'?` | 0 | CALLER · MAREN THACKERY | no |

Advance (`▸ CLASSIFY THE TICKET`) is enabled **only once identified** — by either route.
Entries that identify get the accent-colored panel rule; others get `#3f556b`.

**Phase 2 — `classify`** · label `CLASSIFICATION — YOUR CALL, LOGGED`. Four options, all
selectable, all with notes. Selecting one files it and advances to `ask`. There is no
confirmation and no feedback on correctness at this point.

| Option | Note | Correct |
| --- | --- | --- |
| Phantom Inventory | Listing and shelf disagree. Term of art; she would recognise the situation. | ✅ |
| Storefront Listing Error | The listing is wrong on its face. Node-side. | |
| Lost Shipment Claim | Goods never arrived. Different problem, different form. | |
| Commission Payout Dispute | Courier-side. She runs no legs. | |

The choice is echoed into the feed as `YOU · FILED AS` (gold rule `#8f6522`, tint `#e0b45c`),
text = `<label> — <note>`.

**Phase 3 — `ask`** · label `ASK / VERIFY`. Five investigation options; each is single-use and
costs candle. `norm: 1` findings tag `AS EXPECTED`; `norm: 0` tag `DIVERGES`.

| Option | Cost | Speaker | Tag |
| --- | --- | --- | --- |
| Pull the shipment manifest | 1 | MANIFEST · LEY REGISTRY | AS EXPECTED |
| Check the Node's delivery log | 1 | NODE DELIVERY LOG | **DIVERGES** |
| Ask who has stockroom access | 1 | CALLER · MAREN THACKERY | **DIVERGES** |
| Check for recent bulk activity | 2 | CARAVAN DRAW · CONSTABULARY | **DIVERGES** |
| Ask her about the festival timing | 1 | CALLER · MAREN THACKERY | AS EXPECTED |

Advance (`▸ GIVE HER AN ANSWER`) is always enabled — the player may answer under-informed.
**Red herring design:** "stockroom access" (the nephew) diverges and reads like an answer, but
does not explain the discrepancy. Only *delivery log* + *bulk activity* together support the
true diagnosis.

**Phase 4 — `diagnose`** · label `DIAGNOSIS — ONE ONLY`. Four options; the correct one is
**gated** on having asked both `log` and `bulk` (renders `·` cursor, `opacity .55`, unclickable).

| Option | Note | Gate |
| --- | --- | --- |
| Your nephew took them. I can open a theft report. | Plausible, sincerely offered, and it costs her a nephew. | — |
| The shipment never arrived — I will file a lost-shipment claim. | The manifest disagrees, if you pulled it. | — |
| **A duplicated courier stamp split your lot in two. A Caravan draw shipped the real 36 to the Constabulary. Your potions were sold, not lost.** | Needs the delivery log and the bulk draw before you can say it. | requires `log` + `bulk` |
| Ley instability altered the cargo in transit. | Research has not managed that yet. Saying it anyway is a choice. | — |

When `hardMode` is on, a gated option's note is replaced with `You cannot back this up.`
Diagnosis is echoed to the feed as `YOU · DIAGNOSIS`, rule `#7a8a5e`/tint `#9db07c` if correct,
`#c9707a`/`#d98d95` if not.

**Phase 5 — `status`** · label `DISPOSITION OF TICKET`. Three options; selecting one jumps to
the End of Day screen.

| Option | Note |
| --- | --- |
| Resolve it | You rule on it. It sticks — or it is disputed later. |
| Hold for review | Kicked up for manual review. Slow, safe, remembered as nothing. |
| Transfer | Punted to lot reconciliation. Assumes someone there answers. |

### 4. Account Record

**Purpose:** the asymmetry — the company remembers her, the player does not. Reachable **only
after identification**, from the call header.

- Scrolls. Padding `16px 14px 20px`, gap 12px.
- Title `ACCOUNT 0-4471` — Jersey 15, 30px, `#f2f6fa`. Sub 14px `#8098af`:
  `Company records. Opened once the account matched — not before.`
- **Account panel** (bevel, rule `#6e8fb0`): Maren portrait 128 × 168 + name `The Gilded Hound`
  (Jersey 15, 25px), body 14px/1.45 `#8fa8bf`:
  > Partner (Node) since the second rollout.
  >
  > Named contact on file: M. Thackery.
  - **Standing meter:** label row `STANDING` / `Active`; then a 12-segment bar, each segment
    `flex: 1; height: 11px`, inner shadow `inset 0 0 0 1px rgba(0,0,0,.5)`. First **8** filled
    with the accent color, remaining 4 `#1b2b3c`.
- **Contact log panel** — `CONTACT LOG · LAST THREE`. Each of three entries:
  - Header row: `<date> · <channel>` (Jersey 15, 14px, `#8fa8bf`) / agent name (`#b6cadd`).
  - `Caller:` line 13px, value `#d5e2ee`.
  - Three labelled rows — `REQUEST`, `ACTION`, `OUTCOME` — label column 56px wide,
    Jersey 15 12px `#8098af` ls 1.5px; value 14px/1.4 `#d5e2ee`.
  - Separated by `inset 0 -1px 0 #2b3f56`, `padding-bottom: 10px`.

  Entries (verbatim; note the third caller is *not* the named contact — a deliberate detail):

  1. **9 HARVEST · PARTNER · CASSIDY** — Caller: M. THACKERY (named contact)
     - REQUEST: Storefront listed 12 small healing draughts. Caller counted 20 on her shelf and wanted the listing corrected before a festival order went out.
     - ACTION: Compared the listing against her last two courier receipts. One receipt was never posted to the Node. Posted it and re-synced the listing while she held.
     - OUTCOME: Listing matched her recount. Resolved on the call.
  2. **30 LONGLIGHT · PARTNER · PELL** — Caller: M. THACKERY (named contact)
     - REQUEST: Disputed a size upcharge she says she never authorised. Wanted it reversed.
     - ACTION: Upcharge was applied at her own Node at intake, not by us. Gave her the intake line and the Node reference.
     - OUTCOME: Charge stands, no reversal. She accepted it and stayed unhappy.
  3. **16 LONGLIGHT · PARTNER · THISTLE** — Caller: J. THACKERY (not on file)
     - REQUEST: May a Node refuse a shipment arriving after its posted closing hour?
     - ACTION: Read him the holding rule and the hours on the account.
     - OUTCOME: Answered. No fault. Caller is not the named contact.
- Bottom button (steel): `◂ BACK TO THE CALL` → screen `call`.

### 5. End of Day

**Purpose:** consequences, filed as a record rather than a score.

- Background `linear-gradient(180deg, #141d29, #0b1016)`. Scrolls. Padding `16px 14px 20px`, gap 11px.
- Kicker `MONDAY, 14 HARVEST · CLOSED` (Jersey 15, 15px, `#8fa8bf`, ls 3px);
  title `CANDLE OUT` (Jersey 15, **44px**, `#f2f6fa`).
- **Outcome panel** — rule and tint come from the outcome table below. Label Jersey 15 15px,
  body 16px/1.5 `#eaf2f9`.
- **`WHAT YOU FILED` panel** — key/value rows, key 15px `#9fb8d0` left, value Jersey 15 18px
  `#f2f6fa` right, `inset 0 -1px 0 #2b3f56` separators:

  | Key | Value |
  | --- | --- |
  | Customer Name | `Maren Thackery` — or `never got it` if never identified |
  | Classification | the label; if not the correct class, suffixed ` — reclassified later`; `unclassified` if skipped |
  | Request | `Forty potions ordered, three on the shelf` |
  | Questions asked | `<n> of 5, by candlelight` |
  | Results | outcome `quality` |
  | Dispute risk | outcome `dispute` |
- **`WHAT WILL THE CALLER REMEMBER:` panel** — center-aligned 15px/1.5 `#d5e2ee`, outcome `memory`.
- Two buttons, `margin-top: auto`: **BREAK ROOM** (sage) and **TUESDAY** (light steel; resets the run).

#### Outcome table — key is `(diagnosis === 'sync' ? 'sync' : 'wrong') + '|' + disposition`

| Key | Label | Rule / Tint | Results | Standing | Dispute risk |
| --- | --- | --- | --- | --- | --- |
| `sync\|resolved` | RESOLVED · GROUNDED | `#7a8a5e` / `#9db07c` | Full walkthrough | + warm | none — the record backs you |
| `sync\|hold` | HELD · CORRECT BUT SLOW | `#4a6c8f` / `#9fb8d0` | Correct, deferred | ± flat | low |
| `sync\|transfer` | TRANSFERRED · AFTER THE FACT | `#5f7691` / `#9fb8d0` | Solved, then handed off | ± flat | unknown |
| `wrong\|resolved` | RESOLVED · WRONGLY | `#c9707a` / `#d98d95` | Confident and incorrect | − soured | likely · reopen risk seeded |
| `wrong\|hold` | TRANSFER · UNDECIDED | `#4a6c8f` / `#9fb8d0` | Transfer | − slightly | moderate |
| `wrong\|transfer` | TRANSFERRED | `#5f7691` / `#9fb8d0` | Out of your hands | ± flat | unknown |

Body and memory copy for each key are in `content-reference.md` in this folder (verbatim, exportable to a CMS).

### 6. Break Room

**Purpose:** decompression, world-building, and the only place the game comments on the
player's performance — in dialogue, never as a score.

- Green-shifted palette: page `linear-gradient(180deg,#16211d,#0d1214)`,
  header `linear-gradient(180deg,#1c2a24,#121b18)`, rule `#4c6349`, accent `#9db07c` / `#c8d98f`.
- Header: Bram portrait 128 × 168 (frame `0 0 0 2px #8ba071`), name `Bram` (Jersey 15, 30px),
  role `COWORKER · JUST TO CHAT` (Jersey 15, 14px, `#9db07c`), sub 13px `#8098af`:
  `Two desks over. Opinions, no authority, nothing at stake.`
- Dialogue feed, same panel grammar as the call feed, sage rules. Player lines use
  `linear-gradient(180deg,#1e2b34,#131c23)` with rule `#4a6c8f`, tint `#9fb8d0`.
- **Bram's opening line is chosen by what happened on the call** (evaluated in priority order):

  1. Call closed **without identifying** the caller → *"You closed one without ever getting a name on it. Not judging. Records will though, in about a week, in writing."*
  2. Candle fully spent (`left === 0`) → *"You put a whole candle into one caller on your first day. I am not saying that is wrong. I am saying I noticed, and so did the candle."*
  3. Correct diagnosis (`sync`) → *"Heard you found the Hound her potions. Sold, not stolen — that is a better answer than she was going to get from anybody else on this floor."*
  4. Any other completed diagnosis → *"First one down. However that felt, it felt like that for everybody the first time. Sit."*
  5. Nothing done yet → *"First day. You have the look — like the line is still ringing somewhere behind your eyes."*
- **Reply tree, exactly two levels deep.** Four openers; each has 1–2 follow-ups. After two
  player picks the reply tray empties and the `SAY SOMETHING` heading hides. Full tree in
  `content-reference.md`.
- Bottom button (sage): `▸ BACK TO THE FLOOR` → screen `line`.

### 7. Figurehead Notice

**Purpose:** interstitial policy churn — the world changing the rules between shifts.

- Red-shifted palette: page `linear-gradient(180deg,#1d1519,#0f0c0e)`,
  header `linear-gradient(180deg,#2a1d22,#181114)`, rule `#7d4a52`, accents `#c9707a` / `#d98d95` / `#e2a2a9`.
- Header: Wren portrait 128 × 168 (frame `0 0 0 2px #c9707a`), name `Wren` (Jersey 15, 30px),
  role `SUPERVISOR · MANDATORY COACHING`, sub 13px `#ad9298`:
  `Guaranteed. A new Figurehead has taken office.`
- Speech panel (red bevel), kicker `THE CONCLAVE OUTLINING OPERATIONS & POLICY FOR THE FUTURE`;
  body 16px/1.5 `#f6eef0` (verbatim in `content-reference.md`).
- Steel panel `STANDING POLICIES:` — three gold-`▸` bullets, 15px/1.4 `#eaf2f9`, with the lead
  phrase in `#9fb8d0`:
  - **Pace pressure.** Your candle is cut shorter. Nobody said by how much.
  - **Specialist assignment.** Partner channel only, for you, starting today. This was generalist a fortnight ago. It will be again.
  - **Procedure update.** Step four is now step six. Steps four and five are new. Do not ask about step five.
- Bottom button (steel): `▸ ACKNOWLEDGE (REQUIRED)` → screen `line`. No dismiss, no back.

---

## Interactions & Behavior

**Navigation graph**

```
clockin --LIGHT THE CANDLE--> line
line    --PICK UP-----------> call
call    --OPEN ACCOUNT RECORD (only when identified)--> record --BACK--> call
call    --disposition chosen-> summary
summary --BREAK ROOM--------> breakroom --BACK TO THE FLOOR--> line
summary --TUESDAY-----------> clockin (full state reset)
policy  --ACKNOWLEDGE------> line
```

`policy` has no in-game entry point in this slice; it is reached from the prototype's debug rail.
In production it is an interstitial shown between shifts.

**The candle (time budget)**
- `max = lampNotches` (default 5). `spent = Σ cost of chosen identify options + Σ cost of chosen ask options`.
  `left = max(0, max - spent)`.
- The candle sprite shows `left` as remaining wax height; at 0 it renders a cold stub with no flame.
- An option whose `cost > left` is **not selectable** (dimmed, `·` cursor, `opacity .5`) — the
  player is never allowed to overdraw. There is no timeout and no real-time pressure: time is
  spent only by choosing.
- **Reaching 0 does not end the call.** The player can always finish; running dry costs them
  information, and Bram notices.

**Selection rules**
- Identify and Ask options are single-use (`✓`, dimmed, non-interactive once chosen).
- Classification, diagnosis and disposition are **one-shot** and irreversible — each advances the phase.
- No undo anywhere. No confirmation dialogs.

**States**
- Hover: every menu row lightens (`linear-gradient(180deg,#2b4560,#1a2937)`); buttons lighten
  one step of their own gradient.
- Active/pressed: buttons `transform: translateY(2px)` (3px on the clock-in primary) — the
  bottom `0 4px 0 #070c11` shadow makes it read as a key press.
- Focus: `outline: 2px solid #e0b45c; outline-offset: 2px` on `:focus-visible`.
- Disabled: `opacity: .5`, cursor glyph `·`, no click handler effect.
- Animation: only one — `@keyframes ring` on the ringing label, `1.6s steps(2, end) infinite`,
  opacity `1 → .35 → 1` (deliberately a 2-step square wave, not a smooth fade — it should read
  as a blinking indicator light).
- Loading: art generation is async in the prototype (blank 1×1 GIFs until the first frame
  completes). In production, preload sprites; there is no loading state in the design.
- No error states, no forms, no validation in this slice.

**Scrolling**
- `call` feed, `record`, `summary`, `breakroom` feed and `policy` body scroll independently.
  Header and action tray stay fixed on `call` and `breakroom`.

## State Management

```
screen  : 'clockin'|'line'|'call'|'record'|'breakroom'|'policy'|'summary'
phase   : 'identify'|'classify'|'ask'|'diagnose'|'status'
ident   : string[]        // ids of identify options chosen, in order
klass   : string | null   // chosen classification id
asked   : string[]        // ids of ask options chosen, in order
dx      : string | null   // chosen diagnosis id
status  : string | null   // 'resolved'|'hold'|'transfer'
chat    : string[]        // break-room reply ids, max length 2
```

Derived (not stored):
- `spent`, `left` (candle)
- `identified` = any chosen identify option has `identifies: true`
- outcome = `OUT[(dx === 'sync' ? 'sync' : 'wrong') + '|' + (status ?? 'hold')]`

Transitions: `identify → classify` on advance (gated by `identified`); `classify → ask` on
picking a class; `ask → diagnose` on advance (ungated); `diagnose → status` on picking a
diagnosis; `status → screen: 'summary'` on picking a disposition. `TUESDAY` resets everything
except art.

No data fetching. All content is local. **For production, move `IDENT` / `CLASSES` / `ASKS` /
`DX` / `OUT` / `TALK` / `LOG` into authored case data** (one file per call) so writers can add
cases without touching code; the screens above are the runtime for any such case.

## Tunables (exposed as prototype tweaks)

| Name | Type | Default | Effect |
| --- | --- | --- | --- |
| `lampNotches` | int 3–9 | 5 | Candle length — total time budget for the shift |
| `hardMode` | boolean | false | Replaces a gated diagnosis's note with `You cannot back this up.` (removes the hint about *why* it's gated) |
| `accent` | color | `#4a6c8f` | Accent used for identified-caller rules, standing meter, active rail row. Options: `#4a6c8f` steel, `#7a8a5e` sage, `#a4713f` copper, `#7d5a8f` violet |
| `showRail` | boolean | true | Prototype-only debug screen index. **Do not ship.** |

## Design Tokens

### Palette

*Ground / structure*

| Token | Hex | Use |
| --- | --- | --- |
| page-void | `#070a0f` | Outside the device; darkest ground |
| ink | `#0a1017` | Sprite outline, panel inner border |
| bg-deep | `#0d141c` / `#0c1219` / `#0b1016` | Screen gradient bottoms |
| bg-mid | `#131e2a` / `#14202d` / `#141d29` | Screen gradient tops |
| surface | `#16222f` | Panel gradient bottom |
| surface-lit | `#22344a` | Panel gradient top |
| surface-sunk | `#182530` → `#111a23` | Used/disabled row |
| chrome-top | `#1d2b3c` → `#111a25` | Status bar |
| rule | `#3a536e` | 1px screen-level divider |
| rule-soft | `#2b3f56` | Inner divider, quiet edge |
| bevel-in | `#1b2b3c` | Inner bevel step |
| bevel-out | `#6e8fb0` | Outer bevel highlight |

*Ink on dark*

| Token | Hex | Contrast use |
| --- | --- | --- |
| text-hi | `#f2f6fa` | Headings |
| text | `#eaf2f9` | Body copy, dialogue |
| text-2 | `#d5e2ee` | Secondary body |
| text-3 | `#b6cadd` | Values, quiet labels |
| text-dim | `#a9c2d8` / `#9fb8d0` | Subheads |
| text-muted | `#8fa8bf` | Kickers, meta |
| text-mutest | `#8098af` | Notes, smallest meta |
| text-off | `#3f556b` | Disabled |

*Semantic*

| Token | Hex | Meaning |
| --- | --- | --- |
| gold | `#e0b45c` | The player's agency — actionable cursors, divergent findings, links, focus ring |
| gold-hover | `#f6d38a` | |
| gold-btn | `#f0cd83` → `#c9963f` → `#a97a2c`, ink `#241804` | Primary "commit" action |
| steel | `#4a6c8f` | Default accent, verified/registry information |
| steel-btn | `#33526f` → `#1e3145`, ink `#d5e2ee` | Secondary action |
| light-btn | `#a8c4dc` → `#7fa2c2` → `#6b93b6`, ink `#0b1119` | Shift-level action (clock in, next day) |
| sage | `#7a8a5e` / `#9db07c` / `#c8d98f` | Break room, correct diagnosis, resolved-well |
| sage-btn | `#4c6349` → `#2b3a2a`, ink `#e6eede` | Break room action |
| rose | `#c9707a` / `#d98d95` / `#e2a2a9` | Supervisor, policy, wrong diagnosis |
| copper | `#c9963f` / `#8f6522` | `DIVERGES` finding rule |

All body text meets 4.5:1 against its panel; headline-scale type meets 3:1 minimum.

### Type

Two faces, both pixel-native, loaded from Google Fonts:

- **Jersey 15** — display/UI. All headings, kickers, buttons, labels, tags, numeric values.
  Always with letter-spacing (1.2–3px). Never below 11px.
- **Pixelify Sans** (400–700) — body. All prose, dialogue, notes. Also the `<body>` default.
  Never below 13px.

| Role | Face | Size / line-height | Letter-spacing |
| --- | --- | --- | --- |
| Screen title (clock-in) | Jersey 15 | 52 / .92 | 1px |
| Screen title (summary) | Jersey 15 | 44 / 1 | 1px |
| Screen title | Jersey 15 | 34 / 1 | 1px |
| Panel title / character name | Jersey 15 | 25–30 / 1 | 0–1px |
| Caller name (call header) | Jersey 15 | 28 / 1 | — |
| Button | Jersey 15 | 18–22 | 2–3px |
| Ledger value | Jersey 15 | 18 | — |
| Cursor glyph | Jersey 15 | 16 | — |
| Kicker / meta / speaker | Jersey 15 | 13–15 | 1.5–3px |
| Tag | Jersey 15 | 11–13 | 1.5px |
| Dialogue / body | Pixelify Sans | 16 / 1.5 | — |
| Secondary body | Pixelify Sans | 15 / 1.35–1.5 | — |
| Note / caption | Pixelify Sans | 13–14 / 1.35–1.45 | — |

`text-wrap: pretty` on all prose. `image-rendering: pixelated` on all sprites (mandatory).

### Spacing

Screen padding `12–20px`. Panel padding `12–14px`. Stack gaps `6 / 9 / 11 / 13 / 18px`.
Portrait–text gap `12px`. Cursor column width `11px`. Log label column `56px`.

### Radius

**Zero. Everywhere.** Every corner is square — this is a pixel-art interface and any rounding
breaks the illusion. Never round a panel, button, portrait, or tag.

### Bevel panels (the one structural component)

The interface has essentially **one container**, a chiselled panel drawn entirely with stacked
inset shadows — no borders, no radius:

```
background: linear-gradient(180deg, #22344a 0%, #16222f 100%);
box-shadow:
  inset 0 0 0 1px #0a1017,      /* outer ink line */
  inset 0 0 0 2px <RULE>,       /* the semantic rule colour */
  inset 0 0 0 3px #1b2b3c,      /* inner shadow step */
  inset 0 0 0 4px #0a1017,      /* inner ink line */
  inset 0 5px 0 -4px rgba(255,255,255,.09);  /* top light catch (feed panels only) */
```

`<RULE>` carries the meaning: `#6e8fb0` neutral/record, `#e0b45c` urgent, `#3f556b` routine,
`#c9963f` divergent, `#7a8a5e` correct, `#c9707a` wrong, accent when identified.
A **quiet** variant drops to two steps: `inset 0 0 0 1px #0a1017, inset 0 0 0 2px #2b3f56`
on `linear-gradient(180deg,#1d2b3c,#121b25)`.

Buttons use the same recipe plus a hard bottom edge `0 4px 0 #070c11`.

### Shadows

Only the two above, plus the prototype's device bezel (not app UI). **No soft/blurred shadows
anywhere in the app** — pixel interfaces don't blur.

## Assets

Everything visual in the prototype is **generated at runtime in JavaScript on `<canvas>`** —
there are no image files. This is placeholder art and **must be replaced with authored sprites.**

Required art, at the sizes the layout expects (source resolution × integer upscale):

| Asset | Source px | Displayed | Where |
| --- | --- | --- | --- |
| Character bust ×5 | 64 × 84 | 128 × 168 (2×) | Maren, Unknown (hooded), Bram, Wren, Bracken (authored but unused in this slice) |
| Bust thumbnail | 64 × 84 | 32 × 42 | Waiting rows on The Line |
| Desk scene | 131 × 82 | 393 × 246 (3×) | Clock-in header |
| Candle, one frame per notch | 11 × 21 | 22 × 42 (2×) | Status bar; `lampNotches + 1` frames, full → cold stub |
| TLC sigil | 16 × 16 | 20 × 20 | Status bar |

Art direction to match: 32-bit palette-ramped pixel art, single light source from **upper-left**
(the generator uses a normalized light vector of roughly `(-0.42, -0.58, 0.70)`), ordered
(Bayer 4×4) dithering between ramp steps, a 1px near-black `#0a1017` contour with a soft
one-pixel inner ambient-occlusion step, and a vignetted flat backdrop behind each bust in a
character-specific hue.

Character spec (skin / hair / cloth / trim / headwear) is in `content-reference.md`.

Fonts: **Jersey 15** and **Pixelify Sans** — Google Fonts, OFL, safe to bundle.

Icons: none. The interface uses text glyphs only — `▸ ◂ ◆ ✓ ·` — set in Jersey 15. Keep it that way.

## Files

| File | What it is |
| --- | --- |
| `The Realm - TLC Front Desk.dc.html` | The prototype. Open in a browser; it runs standalone. Interactive reference for every state described above. |
| `support.js` | Runtime the prototype needs to render. Not part of the design; do not port. |
| `_ds/industry-…/` | Stylesheet + bundle the prototype loads. Needed only so the HTML opens correctly; not part of the design. |
| `content-reference.md` | All authored copy — outcome bodies, break-room dialogue tree, policy notice, character art specs — as plain text for a CMS/localization pass. |
| `README.md` | This document. |

To exercise the states: the prototype's right-hand **Screen Index** rail jumps directly to any
screen. Playing the loop normally (`LIGHT THE CANDLE` → `PICK UP`) is the intended read.
