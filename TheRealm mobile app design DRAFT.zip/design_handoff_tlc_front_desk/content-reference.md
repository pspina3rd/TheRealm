# Content reference — TLC Front Desk

All authored copy, verbatim. Everything here is data, not layout: it should end up in a content
file the writers own. Ids match the prototype so cross-referencing the README is direct.

---

## 1. Identify options (`IDENT`)

| id | Player line | Cost | Speaker | Identifies |
| --- | --- | --- | --- | --- |
| `greet` | `"TLC Support. How may I help you?"` | 0 | CALLER · PARTNER CHANNEL | no |
| `name` | `Ask who you are speaking with` | 0 | CALLER · PARTNER CHANNEL | yes |
| `sig` | `Match the ward signature against the registry` | 1 | LEY REGISTRY · MATCH | yes |
| `auth` | `The name is Keyth.   How you doin'?` | 0 | CALLER · MAREN THACKERY | no |

**greet** → "Finally. I ordered forty healing potions for the festival and there are three on my shelf. Three! The festival is tomorrow. Where are the rest of them?"

**name** → "Maren. Maren Thackery, the Gilded Hound, in Import. I have been a Node since the second rollout, which I mention every time."

**sig** → "Signature resolves to acct 0-4471 — the Gilded Hound, Import. Partner, Node sub-role. Named contact: M. Thackery."

**auth** → "I am the one who signs for it, so I would hope so. Do you want the seal number? I have it here somewhere. Somewhere."

---

## 2. Classifications (`CLASSES`)

| id | Label | Note | Correct |
| --- | --- | --- | --- |
| `phantom` | Phantom Inventory | Listing and shelf disagree. Term of art; she would recognise the situation. | yes |
| `listing` | Storefront Listing Error | The listing is wrong on its face. Node-side. | |
| `lost` | Lost Shipment Claim | Goods never arrived. Different problem, different form. | |
| `commission` | Commission Payout Dispute | Courier-side. She runs no legs. | |

---

## 3. Investigation options (`ASKS`)

| id | Player action | Cost | Speaker | Tag |
| --- | --- | --- | --- | --- |
| `manifest` | Pull the shipment manifest | 1 | MANIFEST · LEY REGISTRY | AS EXPECTED |
| `log` | Check the Node's delivery log | 1 | NODE DELIVERY LOG | DIVERGES |
| `access` | Ask who has stockroom access | 1 | CALLER · MAREN THACKERY | DIVERGES |
| `bulk` | Check for recent bulk activity | 2 | CARAVAN DRAW · CONSTABULARY | DIVERGES |
| `festival` | Ask her about the festival timing | 1 | CALLER · MAREN THACKERY | AS EXPECTED |

**manifest** → "Forty units of Healing Draught (small), signed for at the Gilded Hound three mornings ago. Her mark. Nothing lost, nothing pending."

**log** → "Two receipts stamped the same hour by the same courier. One reads 40. One reads 4. Both are valid. The listing believes both."

**access** → "My nephew Ollun has a key. He borrows things. He always says he will put them back and he is always sincere about it."

**bulk** → "A standing bulk order pulled 36 units against acct 0-4471 yesterday, priced and shipped. It drew from a lot that existed twice."

**festival** → "The festival is tomorrow. The festival has been tomorrow for eleven days. I am not being dramatic, I am being early."

> Design note: `access` is the red herring. It diverges from expectation and sounds like a
> solution, but does not explain the 40/4 split. `log` + `bulk` together are the only route to
> the true answer.

---

## 4. Diagnoses (`DX`)

| id | Player line | Note | Gate |
| --- | --- | --- | --- |
| `nephew` | Your nephew took them. I can open a theft report. | Plausible, sincerely offered, and it costs her a nephew. | — |
| `lost` | The shipment never arrived — I will file a lost-shipment claim. | The manifest disagrees, if you pulled it. | — |
| `sync` | A duplicated courier stamp split your lot in two. A Caravan draw shipped the real 36 to the Constabulary. Your potions were sold, not lost. | Needs the delivery log and the bulk draw before you can say it. | requires `log` + `bulk` |
| `ley` | Ley instability altered the cargo in transit. | Research has not managed that yet. Saying it anyway is a choice. | — |

`sync` is the correct diagnosis. Hard mode replaces a gated note with: `You cannot back this up.`

---

## 5. Dispositions

| id | Label | Note |
| --- | --- | --- |
| `resolved` | Resolve it | You rule on it. It sticks — or it is disputed later. |
| `hold` | Hold for review | Kicked up for manual review. Slow, safe, remembered as nothing. |
| `transfer` | Transfer | Punted to lot reconciliation. Assumes someone there answers. |

---

## 6. Outcomes (`OUT`) — keyed `<sync|wrong>|<disposition>`

### `sync|resolved` — RESOLVED · GROUNDED
- Results: `Full walkthrough` · Standing: `+ warm` · Dispute: `none — the record backs you`
- Body: "You told her where the potions went and who has them. She is furious at the Constabulary instead of at you, which is a real service and the only kind available today."
- Caller remembers: "That the potions were sold, not stolen, and that someone read the log instead of guessing. She will still get your name wrong."

### `sync|hold` — HELD · CORRECT BUT SLOW
- Results: `Correct, deferred` · Standing: `± flat` · Dispute: `low`
- Body: "You had it and sent it up anyway. Manual review will confirm what you already knew, three days after the festival."
- Caller remembers: "That she was right to call and that nothing happened."

### `sync|transfer` — TRANSFERRED · AFTER THE FACT
- Results: `Solved, then handed off` · Standing: `± flat` · Dispute: `unknown`
- Body: "You worked it out and passed it to lot reconciliation anyway. They will redo your investigation and note that they did."
- Caller remembers: "A second voice asking the same first question."

### `wrong|resolved` — RESOLVED · WRONGLY
- Results: `Confident and incorrect` · Standing: `− soured` · Dispute: `likely · reopen risk seeded`
- Body: "It sticks. It also comes back — as a dispute, by the end of the week, with a fourth party attached and less patience in the room."
- Caller remembers: "That someone here was very sure. She remembers sureness longer than she remembers answers."

### `wrong|hold` — TRANSFER · UNDECIDED
- Results: `Transfer` · Standing: `− slightly` · Dispute: `moderate`
- Body: "Passed for additional review. The next team reviews your work for correctness."
- Caller remembers: "...???"

### `wrong|transfer` — TRANSFERRED
- Results: `Out of your hands` · Standing: `± flat` · Dispute: `unknown`
- Body: "Handed to whoever owns lot reconciliation. There is such a person. There is no line to them, so this takes the long way around."
- Caller remembers: "A different voice, eventually, asking the same first question."

---

## 7. Break room — Bram

### Opening line, selected by call state (priority order)

1. **Never identified the caller** — "You closed one without ever getting a name on it. Not judging. Records will though, in about a week, in writing."
2. **Candle fully spent** — "You put a whole candle into one caller on your first day. I am not saying that is wrong. I am saying I noticed, and so did the candle."
3. **Correct diagnosis (`sync`)** — "Heard you found the Hound her potions. Sold, not stolen — that is a better answer than she was going to get from anybody else on this floor."
4. **Any other diagnosis** — "First one down. However that felt, it felt like that for everybody the first time. Sit."
5. **Nothing done yet** — "First day. You have the look — like the line is still ringing somewhere behind your eyes."

### Reply tree (`TALK`) — two levels, then the tray empties

**`always`** — You: "Is it always like that?"
> Bram: "No. That is the part nobody warns you about. Tomorrow one will sound exactly like today and be nothing like it. You get good at the shape of a thing, not the thing."

- **`shape`** — You: "The shape."
  > Bram: "History does not repeat. It rhymes though. Learn the rhyme and you will be right more than you are wrong, which is the whole job. Nobody has ever written that down and nobody will."
- **`good`** — You: "How long until I am good at it?"
  > Bram: "You will feel good at it around your fortieth. You will actually be good at it well before that and you will not notice. Those are different days."

**`classify`** — You: "I had to pick what to call it. Nobody checked my work."
> Bram: "Nobody ever will, until it is wrong. That pick is the only real authority they give us and they do not mention it in training. You classified a live problem off four defensible options — that is a judgement, not a form."

- **`wrong`** — You: "And if I picked wrong?"
  > Bram: "Then somebody downstream reclassifies it and the caller waits longer. Rule out what cannot be true first. Whatever is still standing after that is your answer, even when it sounds stupid."

**`name`** — You: "She had a name for me. It was not mine."
> Bram: "Thistle, Cassidy, or Pell. It is always one of those three. They do not remember who helped them, they remember that somebody did, and the name attaches to whoever is nearest in their head."

- **`correct`** — You: "Do I correct them?"
  > Bram: "Not while they are upset. Trust what they tell you happened to them — that part is real. Verify the rest against the record before you act on it. Their memory of you is not the part worth arguing about."

**`sit`** — You: "Nothing. I just needed to sit down."
> Bram: "Good instinct. Best one you have had today."

- **`quiet`** — You: "(say nothing)"
  > Bram: "They put the break room next to the ley conduit, so it hums. You stop hearing it in about a week. Everyone says that like it is a comfort."

> Note: `Thistle`, `Cassidy` and `Pell` are the three agent names in the contact log — the joke
> lands only if those two lists stay in sync.

---

## 8. Figurehead Notice — Wren

Kicker: `THE CONCLAVE OUTLINING OPERATIONS & POLICY FOR THE FUTURE`

Body: "Yes, we know it spells COOP. They claim it was a weird coincidence, if you believe in that sort of thing. Oh, and I know it's your first day, but I am required to make you aware of the following standing policies:
>
Oh, before you read them, they'll probably change again in a couple weeks.
>
The latest Conclave Outline Operations & Policy was just convened last week."

Standing policies:
1. **Pace pressure.** Your candle is cut shorter. Nobody said by how much.
2. **Specialist assignment.** Partner channel only, for you, starting today. This was generalist a fortnight ago. It will be again.
3. **Procedure update.** Step four is now step six. Steps four and five are new. Do not ask about step five.

---

## 9. Contact log (`LOG`) — Account 0-4471

### 9 HARVEST · PARTNER · agent CASSIDY
- Caller: M. THACKERY (named contact)
- Request: Storefront listed 12 small healing draughts. Caller counted 20 on her shelf and wanted the listing corrected before a festival order went out.
- Action: Compared the listing against her last two courier receipts. One receipt was never posted to the Node. Posted it and re-synced the listing while she held.
- Outcome: Listing matched her recount. Resolved on the call.

### 30 LONGLIGHT · PARTNER · agent PELL
- Caller: M. THACKERY (named contact)
- Request: Disputed a size upcharge she says she never authorised. Wanted it reversed.
- Action: Upcharge was applied at her own Node at intake, not by us. Gave her the intake line and the Node reference.
- Outcome: Charge stands, no reversal. She accepted it and stayed unhappy.

### 16 LONGLIGHT · PARTNER · agent THISTLE
- Caller: J. THACKERY (not on file)
- Request: May a Node refuse a shipment arriving after its posted closing hour?
- Action: Read him the holding rule and the hours on the account.
- Outcome: Answered. No fault. Caller is not the named contact.

---

## 10. Other UI copy

**Clock-in**
- `MONDAY · 14 HARVEST 1147` / `Call Center #2`
- "Translocation & Logistics Cooperative. Village of Import. The candle is whole, the line is not empty, and nobody on it has told you their name yet."
- `POSTED THIS MORNING` — "Reminder: the Loading Dock remains a Ballroom. Do not route returned packages to the Loading Dock Ballroom until further notice."
- Button: `LIGHT THE CANDLE`

**The Line**
- `THE LINE` — "Three interactions waiting." / "Discovering who is requesting help, why they do, and what you are capable of doing, before providing support is your goal."
- `◆ LINE ONE · RINGING` / `HELD 00:04` / `Unidentified caller` / "Ward signature present but unmatched." / Button `PICK UP`
- `Line two · End User channel` — "No ward signature. Nothing else offered." — `HELD 02:11`
- `Line three · Business channel` — "Signature matches a high-volume account. Caller unknown." — `HELD 05:40`
- Desk flavor: "On the desk you see scratched: *History doesn't repeat itself, but it does rhyme.*"

**The Call**
- Opening system line, `LINE ONE · CONNECTED` — "Someone is on the line. The registry offers a channel and a ward signature it cannot match. Everything else, you get by asking."
- Menu labels: `OPEN THE CALL` / `CLASSIFICATION — YOUR CALL, LOGGED` / `ASK / VERIFY` / `DIAGNOSIS — ONE ONLY` / `DISPOSITION OF TICKET`
- Advance buttons: `▸ CLASSIFY THE TICKET` / `▸ GIVE HER AN ANSWER`
- Header link: `▸ OPEN ACCOUNT RECORD`
- Feed speaker prefixes: `YOU · FILED AS`, `YOU · DIAGNOSIS`
- Finding tags: `AS EXPECTED` / `DIVERGES`

**Account Record**
- `ACCOUNT 0-4471` — "Company records. Opened once the account matched — not before."
- `The Gilded Hound` — "Partner (Node) since the second rollout." / "Named contact on file: M. Thackery."
- `STANDING` / `Active` · `CONTACT LOG · LAST THREE` · Button `◂ BACK TO THE CALL`

**End of Day**
- `MONDAY, 14 HARVEST · CLOSED` / `CANDLE OUT`
- `WHAT YOU FILED` — row keys: Customer Name, Classification, Request, Questions asked, Results, Dispute risk
- Row values: `never got it` (unidentified), `<class> — reclassified later` (wrong class), `unclassified`, `Forty potions ordered, three on the shelf`, `<n> of 5, by candlelight`
- `WHAT WILL THE CALLER REMEMBER:` · Buttons `BREAK ROOM` / `TUESDAY`

**Break room**
- `Bram` / `COWORKER · JUST TO CHAT` / "Two desks over. Opinions, no authority, nothing at stake."
- `SAY SOMETHING` · Button `▸ BACK TO THE FLOOR`

**Figurehead notice**
- `Wren` / `SUPERVISOR · MANDATORY COACHING` / "Guaranteed. A new Figurehead has taken office."
- `STANDING POLICIES:` · Button `▸ ACKNOWLEDGE (REQUIRED)`

**Status bar**
- `TLC · Support Center` · candle states: `newly lit` / `burning steady` / `burning down` / `burning low` / `guttering` / `the wick is out`

---

## 11. Character art spec

Placeholder busts are generated from these parameters. Use them as the palette brief for the
real sprites. `bg` is the vignetted backdrop behind the bust.

| Character | Headwear | Skin | Hair | Cloth | Trim | Eye | Lip | Blush | Backdrop | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| **Maren Thackery** (the caller) | kerchief | `#c98f63` | `#7a4a28` | `#4a6c8f` | `#b8593f` | `#4a6b3c` | `#9c5a4e` | `#c9705f` | `#2b4560` | Shopkeeper; steel cloth with a rust kerchief |
| **Unidentified caller** | hood | `#8a7f74` | `#2b2f36` | `#3d4d5e` | `#5f7080` | `#7fa8c4` | `#5c5a58` | `#4a4f55` | `#1b2b3c` | Face in shadow, only two eye-glints visible. Desaturated on purpose — the *absence* of a person |
| **Bram** (coworker) | bald + beard | `#c08a5e` | `#5a3a24` | `#7a8a5e` | `#b7a27a` | `#6a4f2c` | `#8f5546` | `#b06553` | `#33422c` | Sage cloth ties him to the break room |
| **Wren** (supervisor) | bun | `#cf9a70` | `#3a2a2e` | `#7d4a52` | `#c9707a` | `#4a5a6b` | `#9c4a52` | `#bf6a68` | `#3a262b` | Rose cloth ties her to the policy screen |
| **Bracken** | long | `#b98a6c` | `#2e2434` | `#4a3550` | `#8f6ba0` | `#8a6f3c` | `#8f4a52` | `#a45a58` | `#3a2b47` | Authored, unused in this slice — a violet channel for a future case |

Shared: 1px contour in `#0a1017`; light from upper-left; 8–16 step tonal ramps with shadows
pulled cool and highlights pulled warm; Bayer 4×4 dithering between steps.

## 12. Lore terms glossary (for consistent localization)

| Term | Meaning |
| --- | --- |
| **TLC** | Translocation & Logistics Cooperative — the employer |
| **COOP** | The Conclave Outlining Operations & Policy for the Future — the governing body; the acronym is a running joke |
| **Figurehead** | Head of the Conclave; changes often, and policy churns with them |
| **Node** | A partner merchant location in the translocation network |
| **Ley line / ley conduit** | The magical infrastructure calls travel over |
| **Ward signature** | A caller's magical identifier — present on the line, but only matches if you look it up |
| **Caravan draw** | A bulk fulfilment pull against an account |
| **Constabulary** | Bulk buyer; recipient of the missing 36 potions |
| **Import** | The village the call center and the Gilded Hound sit in |
| **Harvest / Longlight** | Months of the Realm calendar |
| **The Gilded Hound** | Maren's shop; account 0-4471 |
